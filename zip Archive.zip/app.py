from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)

# MongoDB connection
client = MongoClient(os.getenv('MONGODB_URI'))
db = client.car_catalog

# Collections
cars = db.cars
characteristics = db.characteristics
users = db.users

@app.route('/')
def index():
    return render_template('index.html')

# Cars CRUD
@app.route('/cars')
def list_cars():
    all_cars = list(cars.find())
    return render_template('cars/list.html', cars=all_cars)

@app.route('/cars/add', methods=['GET', 'POST'])
def add_car():
    if request.method == 'POST':
        car = {
            'name': request.form['name'],
            'model': request.form['model'],
            'year': int(request.form['year']),
            'price': float(request.form['price']),
            'characteristics': request.form.getlist('characteristics')
        }
        cars.insert_one(car)
        return redirect(url_for('list_cars'))
    all_characteristics = list(characteristics.find())
    return render_template('cars/add.html', characteristics=all_characteristics)

@app.route('/cars/edit/<id>', methods=['GET', 'POST'])
def edit_car(id):
    if request.method == 'POST':
        cars.update_one(
            {'_id': ObjectId(id)},
            {'$set': {
                'name': request.form['name'],
                'model': request.form['model'],
                'year': int(request.form['year']),
                'price': float(request.form['price']),
                'characteristics': request.form.getlist('characteristics')
            }}
        )
        return redirect(url_for('list_cars'))
    
    car = cars.find_one({'_id': ObjectId(id)})
    all_characteristics = list(characteristics.find())
    return render_template('cars/edit.html', car=car, characteristics=all_characteristics)

@app.route('/cars/delete/<id>')
def delete_car(id):
    cars.delete_one({'_id': ObjectId(id)})
    return redirect(url_for('list_cars'))

# Characteristics CRUD
@app.route('/characteristics')
def list_characteristics():
    all_characteristics = list(characteristics.find())
    return render_template('characteristics/list.html', characteristics=all_characteristics)

@app.route('/characteristics/add', methods=['GET', 'POST'])
def add_characteristic():
    if request.method == 'POST':
        characteristic = {
            'name': request.form['name'],
            'description': request.form['description']
        }
        characteristics.insert_one(characteristic)
        return redirect(url_for('list_characteristics'))
    return render_template('characteristics/add.html')

@app.route('/characteristics/edit/<id>', methods=['GET', 'POST'])
def edit_characteristic(id):
    if request.method == 'POST':
        characteristics.update_one(
            {'_id': ObjectId(id)},
            {'$set': {
                'name': request.form['name'],
                'description': request.form['description']
            }}
        )
        return redirect(url_for('list_characteristics'))
    
    characteristic = characteristics.find_one({'_id': ObjectId(id)})
    return render_template('characteristics/edit.html', characteristic=characteristic)

@app.route('/characteristics/delete/<id>')
def delete_characteristic(id):
    characteristics.delete_one({'_id': ObjectId(id)})
    return redirect(url_for('list_characteristics'))

# Users CRUD
@app.route('/users')
def list_users():
    all_users = list(users.find())
    return render_template('users/list.html', users=all_users)

@app.route('/users/add', methods=['GET', 'POST'])
def add_user():
    if request.method == 'POST':
        user = {
            'name': request.form['name'],
            'email': request.form['email'],
            'phone': request.form['phone'],
            'address': request.form['address']
        }
        users.insert_one(user)
        return redirect(url_for('list_users'))
    return render_template('users/add.html')

@app.route('/users/edit/<id>', methods=['GET', 'POST'])
def edit_user(id):
    if request.method == 'POST':
        users.update_one(
            {'_id': ObjectId(id)},
            {'$set': {
                'name': request.form['name'],
                'email': request.form['email'],
                'phone': request.form['phone'],
                'address': request.form['address']
            }}
        )
        return redirect(url_for('list_users'))
    
    user = users.find_one({'_id': ObjectId(id)})
    return render_template('users/edit.html', user=user)

@app.route('/users/delete/<id>')
def delete_user(id):
    users.delete_one({'_id': ObjectId(id)})
    return redirect(url_for('list_users'))

if __name__ == '__main__':
    app.run(debug=True)
